﻿namespace CarDealer.DTO
{
    public class SuplierDTO
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
