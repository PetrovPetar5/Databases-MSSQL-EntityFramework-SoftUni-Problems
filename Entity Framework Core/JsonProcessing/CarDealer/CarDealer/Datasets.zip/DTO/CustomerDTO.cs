﻿using System;

namespace CarDealer.DTO
{
    public class CustomerDTO
    {
        public string Name { get; set; }

        public string BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}
