﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
   public class PartDTO
    {
        public string Name { get; set; }

        public string Price { get; set; }

        public int Quantity { get; set; }

        public int SupplierId { get; set; }
    }
}
