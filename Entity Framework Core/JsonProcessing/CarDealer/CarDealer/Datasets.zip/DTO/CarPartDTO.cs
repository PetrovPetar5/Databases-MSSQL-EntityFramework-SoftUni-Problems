﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
   public class CarPartDTO
    {
        public PartDTO PartsInfo { get; set; }

        public CarDTO CarInfo { get; set; }
    }
}
